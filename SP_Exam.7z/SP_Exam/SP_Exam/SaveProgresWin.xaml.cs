﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SP_Exam
{
    /// <summary>
    /// Логика взаимодействия для SaveProgresWin.xaml
    /// </summary>
    public partial class SaveProgresWin : Window
    {
        public SaveProgresWin()
        {
            InitializeComponent();
            PBar.Value = 0;
            PBar.Maximum = 14;
            //Task t = DisplayResultAsync();
            //t.Wait();
            for (int i = 0; i < 14; i++)
            {
                PBar.Value = i;
            }
        }

        
    }
}
