﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32;

namespace SP_Exam
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<People> list;

        public event Action<int> ffff;
        public MainWindow()
        {
            InitializeComponent();
            Bar.Value = 1;
            Bar.Maximum = 14;
            Bar.Minimum = 0;
            ffff += OnFfff;

        }

        List<People> TestData()
        {
            list = new List<People>();
            list.Add(new People {Age = 44,Adress ="Vinnitca",Balance = 10000,Name = "Ivan"});
            list.Add(new People { Age = 443, Adress = "Vinnitca", Balance = 15454000, Name = "Ilona" });
            list.Add(new People { Age = 1, Adress = "Vinnitca", Balance = 0, Name = "Ivanka" });
            list.Add(new People { Age = 44, Adress = "Vinnitca", Balance = 10000, Name = "Gavrik" });
            list.Add(new People { Age = 44, Adress = "Vinnitca", Balance = 10000, Name = "Kaban" });
            list.Add(new People { Age = 44, Adress = "Vinnitca", Balance = 10000, Name = "Mouse" });
            list.Add(new People { Age = 44, Adress = "Vinnitca", Balance = 10000, Name = "Jone" });
            list.Add(new People { Age = 44, Adress = "Vinnitca", Balance = 10000, Name = "Lyda" });
            list.Add(new People { Age = 24, Adress = "Vinnitca", Balance = 999999999, Name = "Serg" });
            list.Add(new People { Age = 14, Adress = "Vinnitca", Balance = 10000, Name = "Kolya" });
            list.Add(new People { Age = 4114, Adress = "Vinnitca", Balance = 10000, Name = "dsfgsd" });
            list.Add(new People { Age = 414, Adress = "Vinnitca", Balance = 10000, Name = "ggggggg" });
            list.Add(new People { Age = 4344, Adress = "Vinnitca", Balance = 10000, Name = "errrrrrrrrrr" });
            list.Add(new People { Age = 4344, Adress = "Vinnitca", Balance = 10000, Name = "aerarara" });
            return list;

        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DataGrid1.ItemsSource = TestData();
        }


         void LoadXml(object filename)
        {
           
            list = new List<People>();
          
            XDocument xdoc = XDocument.Load(filename as string);
           var xElements = xdoc.Element("Peoples")?.Elements("People");
            if (xElements != null)
               foreach (XElement pElement in xElements)
               {
                    DataGrid1.ItemsSource = list;
                   Bar.Maximum = 14;
                   Bar.Value++;
                    list.Add(new People
                    {
                        Age = int.Parse(pElement.Element("Age")?.Value),
                        Adress = pElement.Element("Adress")?.Value,
                        Balance = decimal.Parse(pElement.Element("Balance")?.Value),
                        Name = pElement.Attribute("Name")?.Value
                    });
                    
                }
          
           
            
        }

        
        async Task<XElement>  Node()
        {
            XElement xEmp =null;

          SaveProgresWin sav = new SaveProgresWin();
            sav.Show();
            sav.PBar.Value = 0;
            sav.PBar.Maximum = 14;
            await Task.Run(() =>
            {
               
            
                xEmp =
                 new XElement("Peoples",
                    list.Select(p =>
                         new XElement("People",
                             new XAttribute("Name", p.Name),
                             new XElement("Age", p.Age),
                             new XElement("Adress", p.Adress),
                             new XElement("Balance", p.Balance))));
               
              
               
            });
            
            return xEmp;
        }
         public async Task SaveToXML(string file)
         {
             if (list == null || list.Count < 1)
             {
                 MessageBox.Show("No data", "eror", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
             }



        
            XDocument xdoc = new XDocument(await Node());
           
            xdoc.Save(file);
            
         }

        
       
        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                DefaultExt = "xml|*.xml",
                AddExtension = true,
                Filter = "xml|*.xml"
            };
            if (saveFileDialog.ShowDialog() == _contentLoaded)
            {
              await SaveToXML(saveFileDialog.FileName);
               // Bar.Maximum = 14;
                //for (int i = 0; i < 14; i++)
                //{
                //    Bar.Value=i;
                //    Thread.Sleep(500);
                //}
            } 
            
            
        }

        private  void Button_Click_2(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "xml |*.xml";
            openFileDialog.RestoreDirectory = true;
           
            if (openFileDialog.ShowDialog() == _contentLoaded)
            {
            //Thread th1 = new Thread(LoadXml);
                
                // th1.Start();
                 LoadXml(openFileDialog.FileName);

            }
        }


        protected  void OnFfff(int obj)
        {
            
        }
    }
}
