﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfSlider
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            SliderR.Value = SliderB.Value = SliderG.Value = 255;
        }

        private void Sliders_ValueChanged(object sender , RoutedPropertyChangedEventArgs<double> e)
        {
            Background = new SolidColorBrush(Color.FromRgb((byte)SliderR.Value,(byte)SliderG.Value,(byte)SliderB.Value));

            if (SliderB.Value < 30 && SliderG.Value < 30 && SliderR.Value < 75)
            {
                LabelB.Foreground = LabelG.Foreground = LabelR.Foreground = Brushes.Azure;
            }
            else
            {
                LabelB.Foreground = LabelG.Foreground = LabelR.Foreground = Brushes.Black;
            }

        }
    }
}
